import os
import re
from itertools import islice,izip
from collections import Counter
import pickle
import string
import nltk
from string import maketrans
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer
from nltk.tokenize import sent_tokenize, word_tokenize
rouge={}
with open("C:\Users\KC-L\Documents\\Summarization_values.txt", "rb") as myFile:
    top = pickle.load(myFile)
with open("C:\Users\KC-L\Documents\\Summarization_sent.txt", "rb") as myFile:
    sent = pickle.load(myFile)
directory = os.path.normpath(r"C:\Users\KC-L\Documents\IR1")
for subdir, dirs, files in os.walk(directory):
    for file in files:
        print str(file)
        rouge[str(file)]={}
        f = open(os.path.join(subdir, file), 'r')
        a = f.read()
        info = a.lower()
        cleanr = re.compile('<.*?>')
        l = re.sub(cleanr, '', info)
        # trantab = maketrans(".", "\n")
        # l=l.translate(trantab)
        # l=l.translate(None,string.punctuation)
        info = re.sub(ur"[^\w\d.\s]+", '', l)
        ind=1
        print top[str(file)]
        text = []
        for line in top[str(file)]:
           # print sent[str(file)][line]
            if ind==1:
                text.append(sent[str(file)][line])
            ind+=1
        print text[0]
        #print sent[str(file)][line]
        h1 = []
        h1.append(raw_input("Enter your review"))
        h2 = []
        h2.append(raw_input("Enter your review"))
        bi1 = [b for l in h1 for b in zip(l.split(" ")[:-1], l.split(" ")[1:])]
        bi2 = [b for l in h2 for b in zip(l.split(" ")[:-1], l.split(" ")[1:])]
        bigrams = [b for l in text for b in zip(l.split(" ")[:-1], l.split(" ")[1:])]
        #print bigrams
        count = 1
        for i in bigrams:
            #print i
            rouge[str(file)][i]=count
        s=0
        #print rouge
        for i in bi1:
            #print i
            if i in rouge[str(file)]:
                s+=1
        for i in bi2:
            if i in rouge[str(file)]:
                s+=1

        print "Score:",s/(len(bi1)+len(bi2))
        print
#print sent