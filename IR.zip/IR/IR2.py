import os
import pickle
import math
import nltk
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer
from nltk.tokenize import sent_tokenize, word_tokenize
ps=PorterStemmer()
with open("C:\Users\KC-L\Documents\Dictionary_Values.txt", "rb") as myFile:
    pos_index = pickle.load(myFile)
#print new_Dict
#tf
tf={}
for word in pos_index:
    tf[word] = {}
    temp = {}
    for file in pos_index[word]:
        #print file
        #temp[str(file)]+=len(new_Dict[words][str(file)])
        temp[file]=1+math.log(len(pos_index[word][file]),10)
    tf[word]=temp
print tf
#idf
idf={}
total_files=5435
for word in pos_index:
    idf[word]=math.log((total_files/len(pos_index[word])),10)
print idf
#tf-idf
tf_idf={}
for query in pos_index:
    tf_idf[query]={}
    tem={}
    for doc in tf[query]:
        tem[doc]=(tf[query][doc]*idf[query])
    tf_idf[query]=tem
print tf_idf
with open("C:\Users\KC-L\Documents\idf_values.txt", "wb") as myFile:
    pickle.dump(idf, myFile)
with open("C:\Users\KC-L\Documents\\tf_values.txt", "wb") as myFile:
    pickle.dump(tf, myFile)
with open("C:\Users\KC-L\Documents\\tf_idf_values.txt", "wb") as myFile:
    pickle.dump(tf_idf, myFile)
