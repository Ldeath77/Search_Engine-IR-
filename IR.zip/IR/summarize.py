import pickle
import os
import string
import re
import nltk
from string import maketrans
from collections import OrderedDict
from operator import itemgetter
import operator
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer
from nltk.tokenize import sent_tokenize, word_tokenize
with open("C:\Users\KC-L\Documents\\tf_idf_values.txt", "rb") as myFile:
    tf_idf = pickle.load(myFile)

ps=PorterStemmer()
summarization={}
sum_sent={}
# taking all the words --------------------
def splitsent(sent):
    wordlist=[]
    word=""
    wordlist=sent.split(" ")
    if '' in wordlist:
        wordlist.remove('')
    return wordlist
directory = os.path.normpath(r"C:\Users\KC-L\Documents\IR1")
for subdir, dirs, files in os.walk(directory):
    for file in files:
#taking sentences
        summarization[str(file)]={}
        sum_sent[str(file)]={}
        f= open(os.path.join(subdir,file),'r')
        info=f.read()
        #print  info
        info = info.lower()
        cleanr = re.compile('<.*?>')
        info = re.sub(cleanr, '', info)
        #print info
        #trantab = maketrans(".", "\n")
        #info=info.translate(trantab)
        #info = info.translate(None, string.punctuation)
        info=re.sub(ur"[^\w\d.\s]+",'',info)
        #print info
        sentlist=[]
        sent=""
        sentencenumber=1
        for i in info:
            currentsent={}

            if i != "." and i!="\n":
                sent=sent+i

            else:
                if sent!="":
                    currentsent[sentencenumber]=sent.lower()
                    sentlist.append(currentsent)
                    sent=""
                    sentencenumber+=1
        #print sentlist
        sentence=[]
        sentencenumber=0

        for i in sentlist:
            currentsent={}
            sentencenumber+=1
            sent=splitsent(i[sentencenumber])
            currentsent[sentencenumber]=sent
            sentence.append(currentsent)

        senttfidf={}
        sentencenumber=0
        #print(sentence)
        #finding avg tf-idf for each sentence
        for k in sentence:
            #print sentence
            for dic in k:
                array=k[dic]
                summ=0
                for i in array:
                    k1=ps.stem(i)
                    if k1 in tf_idf:
                        if file in tf_idf[k1]:
                            summ+=tf_idf[k1][file]
                summ=summ/len(array)
                #print summ
                summarization[str(file)][dic]=summ
                sento=' '.join(map(str, array))
                sum_sent[str(file)][dic]=sento
                #print array
                #summsents.append(summ)

#print summarization
summary={}
for i in summarization:
    sent={}
    sent = OrderedDict(sorted(summarization[i].items(), key=lambda x:x[1], reverse=True))
    summary[i]=sent
    #print summary[i]
top6={}
for i in summary:
    k={key:value for key,value in summary[i].items()[0:3]}
    top6[i]=k
#    print top3[i]
    #last3sent = {k: sortedsent[k] for k in sortedsent.keys()[:3]}
sum_t={}
for i in top6:
    sum_t[i]=[]
    for j in top6[i]:
        #print sum_sent[i][j]
        sum_t[i].append(sum_sent[i][j])
        print
print sum_t
with open("C:\Users\KC-L\Documents\Summarization_values.txt", "wb") as myFile:
    pickle.dump(top6, myFile)
with open("C:\Users\KC-L\Documents\Summarization_sent.txt", "wb") as myFile:
    pickle.dump(sum_sent, myFile)
with open("C:\Users\KC-L\Documents\Summarization_total.txt", "wb") as myFile:
    pickle.dump(sum_t, myFile)