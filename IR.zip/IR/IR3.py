import os
import Tkinter
from Tkinter import *
from collections import OrderedDict
import math
from operator import mul
import pickle
import string
import nltk
from string import maketrans
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer
from nltk.tokenize import sent_tokenize, word_tokenize
with open("C:\Users\KC-L\Documents\\tf_idf_values.txt", "rb") as myFile:
    tf_idf = pickle.load(myFile)
with open("C:\Users\KC-L\Documents\\tf_values.txt", "rb") as myFile:
    o_tf = pickle.load(myFile)
with open("C:\Users\KC-L\Documents\idf_values.txt", "rb") as myFile:
    o_idf = pickle.load(myFile)
with open("C:\Users\KC-L\Documents\Summarization_total.txt", "rb") as myFile:
    sum_t = pickle.load(myFile)
#print tf_idf
global query
query=""
ps = PorterStemmer()

def get_query_words(k_query):
    list=[]
    query=[]
    list = k_query.lower()
    list = list.translate(None, string.punctuation)
    list = word_tokenize(list)
    for word in list:
        word = ps.stem(word)
        query.append(word)
    return query
def cosine_simi(query_list,doc_l,doc):
    tf={}
    wt={}
    cs={}
    sum=0
    sum1=0
    sum2=0
    for term in query_list:
        if term in tf:
            tf[term]+=1
        else:
            tf[term]=1
    for lis in doc_l:
        lis = ps.stem(lis)
        if lis in tf:
            wt[lis]=(tf[lis])*o_idf[lis]
            sum1+=wt[lis]*wt[lis]
            cs[lis]={}
            cs[lis][doc]=wt[lis]*o_tf[lis][doc]
            sum+=cs[lis][doc]
            sum2+=cs[lis][doc]*cs[lis][doc]
        else:
            wt[lis]=0
            sum1 += wt[lis] * wt[lis]
            cs[lis] = {}
            cs[lis][doc]=0
            sum += cs[lis][doc]
            sum2 += cs[lis][doc] * cs[lis][doc]
    #print sum1,sum2,sum
    ret=0
    if(sum1!=0 and sum2!=0):
        return sum/math.sqrt(sum1)*math.sqrt(sum2)
    else:
        return 0
#gui

#gui
query=raw_input("Enter Your Query:")
output_q=get_query_words(query)
print "Query:",query
cosine_value={}
cosine_value[query] = {}
directory = os.path.normpath(r"C:\Users\KC-L\Documents\IR1")
for subdir, dirs, files in os.walk(directory):
    for file in files:
        #cosine_simi(each_q,file)
        f = open(os.path.join(subdir, file), 'r')
        a = f.read()
        l = a.lower()
        trantab = maketrans(".", "\n")
        l = l.translate(trantab)
        l = l.translate(None, string.punctuation)
        l = word_tokenize(l)
        value=cosine_simi(output_q,l,str(file))
        #print value
        cosine_value[query][str(file)]=value
#print cosine_value
decrease= OrderedDict(sorted(cosine_value[query].items(), key=lambda x:x[1], reverse=True))
decrease={key:value for key,value in decrease.items()[0:3]}
#print decrease
for k in decrease:
    print "File:",k
    print "Summary(top 3 lines):"
    for each_line in sum_t[k]:
        print each_line
with open("C:\Users\KC-L\Documents\\Cosine_values.txt", "wb") as myFile:
    pickle.dump(cosine_value, myFile)
