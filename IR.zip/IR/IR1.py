import os
import pickle
import re
import string
import nltk
from string import maketrans
from nltk.tokenize import word_tokenize
from nltk.stem import PorterStemmer
from nltk.tokenize import sent_tokenize, word_tokenize
#initializing
dict1={}
l=[]
tuple=[]
ps=PorterStemmer()
#getting files
directory = os.path.normpath(r"C:\Users\KC-L\Documents\IR1\1")
for subdir, dirs, files in os.walk(directory):
    for file in files:
        count=1
        f=open(os.path.join(subdir,file),'r')
        a=f.read()
        #print(a)
        #print(file)
        #trantab = maketrans(",", " ")
        l=a.lower()
        #print l
        cleanr = re.compile('<.*?>')
        l = re.sub(cleanr, '', l)
        #trantab = maketrans(".", "\n")
        #l=l.translate(trantab)
        #l=l.translate(None,string.punctuation)
        l=re.sub(ur"[^\w\d.\s]+", '', l)
        #print l
        l = word_tokenize(l)
        #print l
        for words in l:
            words=ps.stem(words)
            #print(words)
            k=[]
            if words in dict1:
                l=dict1[words]
                if str(file) in l:
                       k=l[str(file)]
                       k.append(count)
                else:
                    l[str(file)]=[]
                    k.append(count)
                    l[str(file)]=k
                #print(dict1)
            else:
                dict2={}
                dict2[str(file)]=[]
                k.append(count)
                dict2[str(file)]=k
                #dict1[words]=[]
                dict1[words]=dict2
                #print(dict1)
            count=count+1
        f.close()

print(dict1)

with open("C:\Users\KC-L\Documents\Dictionary_Values.txt", "wb") as myFile:
    pickle.dump(dict1, myFile)
