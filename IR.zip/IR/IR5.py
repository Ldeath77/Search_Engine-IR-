from Tkinter import *
import pickle
def submit_query():
    with open("C:\Users\KC-L\Documents\Cosine_Values.txt", "rb") as myFile:
        cosine = pickle.load(myFile)
    print cosine
root = Tk(className="Search Engine") # creates root window
# all components of thw window will come here
L1 = Label(root, text="User Name")
L1.pack( side = LEFT)
E1 = Entry(root, bd =5)
E1.pack(side = RIGHT)
B = Button(root, text ="Hello", command = submit_query)
B.pack()
root.mainloop() # To keep GUI window running
#new
root = Tk(className="Search Engine") # creates root window

#top = Tkinter.Tk()
def submit_query():
   query=E1.get()
   root.destroy()
   print query
# all components of thw window will come here
L1 = Label(root, text="User Name")
L1.pack( side = LEFT)
E1 = Entry(root, bd =5)
E1.pack(side = RIGHT)
#B = Button(root, text ="Hello", command = submit_query)
B = Tkinter.Button(root, text ="Hello", command = submit_query)
B.pack()
root.mainloop() # To keep GUI window running